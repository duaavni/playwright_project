export enum GenderOptions {
    MALE,
    FEMALE
}